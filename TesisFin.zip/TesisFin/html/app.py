from flask import Flask, render_template, request
from feature_extraction import FeatureExtraction
import joblib
import pandas as pd
import os
from extract_msg import Message
import re

app = Flask(__name__)
model = joblib.load(
    'C:/Users/Predator/Documents/Python/Elementos_Basicos/teisahjdfks/Modelo_entrenado.pkl')  # Cargar el modelo entrenado
phishing_links = []  # Lista para almacenar los enlaces phishing
excel_file = 'phishing_links.xlsx'  # Nombre del archivo de Excel

# Crear el archivo de Excel si no existe
if not os.path.exists(excel_file):
    df = pd.DataFrame({'Enlaces phishing': []})
    df.to_excel(excel_file, index=False)


def extract_url_from_msg(file_path):
    with Message(file_path) as msg:
        content = msg.body  # Obtén el contenido del cuerpo del mensaje
        urls = re.findall(r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+', content)

    return urls


@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        url = request.form['url']
        features = FeatureExtraction(url).features
        prediction = model.predict([features])[0]  # Realizar la predicción con el modelo

        if prediction == -1:
            result = "El enlace es phishing."
            phishing_links.append(url)  # Agregar el enlace phishing a la lista

            # Guardar la lista en el archivo de Excel
            df = pd.DataFrame({'Enlaces phishing': phishing_links})
            df.to_excel(excel_file, index=False)

        else:
            result = "El enlace no es phishing."

        return render_template('index.html', url=url, result=result)

    return render_template('index.html')


@app.route('/phishing', methods=['POST'])
def phishing():
    file = request.files['file']
    file.save(file.filename)
    urls = extract_url_from_msg(file.filename)

    if urls:
        url = urls[0]
        features = FeatureExtraction(url).features
        prediction = model.predict([features])[0]  # Realizar la predicción con el modelo

        if prediction == -1:
            result = "El enlace es phishing."
            phishing_links.append(url)  # Agregar el enlace phishing a la lista

            # Guardar la lista en el archivo de Excel
            df = pd.DataFrame({'Enlaces phishing': phishing_links})
            df.to_excel(excel_file, index=False)

        else:
            result = "El enlace no es phishing."
    else:
        result = "No se encontró ninguna URL en el archivo .msg."

    return render_template('index.html', url=url, result=result)


if __name__ == '__main__':
    app.run()